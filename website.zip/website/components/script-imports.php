<script src="assets/js/jquery.js" type='text/javascript'></script>
<script type="text/javascript" src="assets/js/jquery-cookie/jquery.cookie.js"></script>
<script type="text/javascript" src="assets/js/swiper/swiper-bundle.min.js"></script>
<script src="assets/js/app.js" type='text/javascript'></script>
<script src="assets/js/top-bar.js" type='text/javascript'></script>
<script src="assets/js/home.js" type='text/javascript'></script>