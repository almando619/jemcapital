const Config = {
  PATHNAME: "/jemcapital/website",
  HREF_START_INDEX: 19,
};
