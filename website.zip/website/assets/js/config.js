const Config = {
  PATHNAME: "",
  HREF_START_INDEX: 0,
};
