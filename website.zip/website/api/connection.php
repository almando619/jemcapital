<?php
$DB_USER = "root";
$DB_PASSWORD = "";
$DB_HOST = "localhost";
$DB_NAME = "jemcapital";

$conn = mysqli_connect($DB_HOST, $DB_USER, $DB_PASSWORD, $DB_NAME);
